Place all dependent libraries here. To include library JS sources in project sources, use the following macro:

//#INSERTFILE "../lib/path/to/lib.js"
